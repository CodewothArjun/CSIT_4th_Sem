male('Asha Kaji').
female('Chaitya Maya').
female('Anita').
male('Sanjay').
father('Asha Kaji','Anita').
father('Asha Kaji','Sanjay').
mother('Chaitya Maya','Anita').
mother('Chaitya Maya','Sanjay').
husband('Asha Kaji','Chitya Maya').
sister('Anita','Sanjay').
brother('Sanjay','Anita').
grandfather('Purna','Sanjay').
grandfather('Purna','Anita').
father('Purna','Asha Kaji').
grandson('Sanjay','Purna').
granddaughter('Anita','Purna').
