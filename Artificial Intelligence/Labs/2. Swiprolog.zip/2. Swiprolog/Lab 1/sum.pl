sum:-
write('Enter first number : '),read(X),
write('Enter second number : '),read(Y),
Z is X+Y,
write('Sum is '),write(Z).