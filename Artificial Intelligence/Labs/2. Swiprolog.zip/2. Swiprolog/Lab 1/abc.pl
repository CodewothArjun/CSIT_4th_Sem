sum:-
write('Enter first number : '),read(X),
write('Enter second number : '),read(Y),
Z is X + Y,
write(X),write(' + '),write(Y),write(' = '),write(Z).