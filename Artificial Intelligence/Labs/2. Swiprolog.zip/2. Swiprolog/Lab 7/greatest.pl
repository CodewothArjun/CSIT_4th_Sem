greatest(X,Y,Z):-
X>Y,Z is X.
greatest(X,Y,Z):-
X<Y,Z is Y.