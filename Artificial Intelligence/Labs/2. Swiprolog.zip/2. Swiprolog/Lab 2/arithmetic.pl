operation:-
write('Enter first number : '),read(X),
write('Enter second number : '),read(Y),
A is X + Y,
S is X - Y,
M is X * Y,
D is X / Y,
E is X//Y,
write('Sum is : '),write(A),nl,
write('Difference is : '),write(S),nl,
write('Multiplication is : '),write(M),nl,
write('Division is : '),write(D),nl,
write('Integer division is : '),write(E).

square:-
write('Enter a number : '),read(N),
Z is N * N,
write('Square of '),write(N),write(' is '),write(Z).

cube:-
write('Enter a number : '),read(M),
C is M * M * M,
write('Cube of '),write(M),write(' is '),write(C).

modulus:-
write('Enter first number : '),read(P),
write('Enter second number : '),read(Q),
R is P mod Q,
write(P),write(' modulus '),write(Q),write(' is '),write(R).