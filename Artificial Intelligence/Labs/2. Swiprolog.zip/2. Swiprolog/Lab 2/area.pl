area:-
write('Enter the length of the rectangle : '),read(L),
write('Enter the breadth of the rectangle : '),read(B),
A is L * B,
write('Area of the rectangle is '),write(A).

perimeter:-
write('Enter the length of the rectangle : '),read(X),
write('Enter the breadth of the rectangle : '),read(Y),
P is 2 * (X + Y),
write('Perimeter of the rectangle is '),write(P).

circlearea:-
write('Enter the radius of the circle : '),read(R),
B is 22/7 * R * R,
write('The area of the circle is '),write(B).

circumference:-
write('Enter the radius of the circle :'),read(S),
C is 2 * 22 / 7 * S,
write('The circumference of the circle is '),write(C).