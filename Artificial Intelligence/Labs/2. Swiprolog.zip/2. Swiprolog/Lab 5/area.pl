area:-
write('Enter height of the triangle : '),
read(H),
write('Enter base of the triangle : '),
read(B),
A is 1/2* B*H,
write('The area of the triangle is : '),write(A).
