cube:-
write('Enter a number : '),
read(X),
Y is X * X * X,
write('Cube of '),write(X),write(' is '),write(Y).