mortal(X):- 
	man(X).
man(ram).
man(shyam).