cat(tom).
animal(X):-cat(X).
thamel(kathmandu).
ason(kathmandu).

